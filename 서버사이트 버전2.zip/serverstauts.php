<?php
	session_start();
?>

<?php require('board/config/config-fivem.php'); ?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>서버현황</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>

<!-- Scrollbar -->
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">
<?php
		$settings['title'] = "";
		$settings['ip'] = $ip;
		$settings['port'] = $port;
		$settings['max_slots'] = $max_slots;

		@$content = json_decode(file_get_contents("http://".$settings['ip'].":".$settings['port']."/info.json"), true);
		@$img_d64 = $content['icon'];
		if($content) {
		$gta5_players = file_get_contents("http://".$settings['ip'].":".$settings['port']."/players.json");
		$gta5_players1 = file_get_contents("http://".$settings['ip'].":".$settings['port']."/players.json");
		$content = json_decode($gta5_players, true);
		$content1 = json_decode($gta5_players1, false);
		$pl_count = count($content);
?>
		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>

				<!-- Banner -->
					<section id="wrapper">
						<header>

<div id="load_tweets">
<div class="inner">
	<h2>플레이어 / 고유번호 / 현재인원: <?= $pl_count ?>명 </h2>
</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.0/jquery.min.js"></script>
<script type="text/javascript">
var auto_refresh = setInterval(
function ()
{
$('#load_tweets').load('serverstauts.php').fadeIn("slow");
}, 500000); /* 새로고침  1000은 1초를 의미,  새로고침을 빨리하게되면 오류 또는 터지는 경우가 발생하므로 50분 이상으로 맞춰주세요. */
</script>

<?php
for ($i=0; $i <count($content) ; $i++) {
?>
<div class="inner">
    <th><?php echo $content[$i]["id"]; ?></th>
    <th><?php echo $content[$i]["name"]; ?></th></br>
</div>
<?php
}
?>
						</header>
</div>


				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
					</section>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
	</body>
</div>
</html>

<?php } else {
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>서버현황</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>

<!-- Scrollbar -->
<div id="scrollbar" class="scrollbar">
	<body class="is-preload">
		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>

				<!-- Banner -->
					<section id="wrapper">
						<header>
							<div id="load_tweets">
							<div class="inner">
								<h2>플레이어 / 고유번호</h2>
								<th>서버가 오프라인 또는 IP, PORT가 잘못 입력되었습니다.</th><br><br><br></br>
								</div>
						</header>
						</div>

				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
					</section>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
	</body>
</div>
</html>

<?php
}
?>
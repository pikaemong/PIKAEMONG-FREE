<main>
<section class="card">
<section class="header">
<div class="title"><a rel="bookmark"><?php echo $row['b_title']?></a></div>
</section>
<div class="split"></div>
<table>
<tbody>
<p><span style="color: #00ccff;">
<strong>
<span id="boardID">작성자: <?php echo $row['b_id']?></br></span>
<span id="boardDate">작성일: <?php echo $row['b_date']?></br></span>
<span id="boardHit">조회: <?php echo $row['b_hit']?></br></span></strong></span>
<div id="boardContent"></br><?php echo $row['b_content']?></div>
</p>
</tbody>
</table>
</section>
</main>
<?php
	require_once("config/dbconfig.php");
	$bNo = $_GET['pikaemong'];

	if(!empty($bNo) && empty($_COOKIE['board_free_' . $bNo])) {
		$sql = 'update board_free set b_hit = b_hit + 1 where b_no = ' . $bNo;
		$result = $db->query($sql); 
		if(empty($result)) {
			?>
			<script>
				alert('오류가 발생했습니다.');
				history.back();
			</script>
			<?php 
		} else {
			setcookie('board_free_' . $bNo, TRUE, time() + (60 * 60 * 24), '/');
		}
	}
	
	$sql = 'select b_title, b_content, b_date, b_hit, b_id from board_free where b_no = ' . $bNo;
	$result = $db->query($sql);
	$row = $result->fetch_assoc();
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>포럼</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">
	
		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>
				
				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2><?php echo $row['b_title']?></h2>
							</div>
						
						
					<div class="inner">	
						<th>작성자: <?php echo $row['b_id']?></th></br>
						<th>작성일: <?php echo $row['b_date']?></th></br>
						<th>조회: <?php echo $row['b_hit']?></th></br>
						</br><?php echo $row['b_content']?>
					</div>
					</header>

					</section>
					
				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
	</body>
</div>
</html>
<section id="footer">
	<div class="inner">
		<ul class="contact">
			<li class="icon solid fa-home">
				서버 주소</br>fivem://connect/다이렉트
			</li>
								
			<li class="icon solid fa-envelope">
				디스코드 주소</br>https://discord.gg/초대코드
			</li>
		</ul>
		
		<ul class="copyright">
			<li>Modifier: PIKAEMONG</li>
		</ul>
	</div>
</section>
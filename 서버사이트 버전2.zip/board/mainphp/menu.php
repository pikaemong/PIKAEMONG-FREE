<?php require('config/config-fivem.php'); ?>

<!-- Header -->
<header id="header" class="alt">
	<nav>
		<a href="#menu">메뉴</a>
	</nav>
</header>

<?php
	$ip = $_SERVER['REMOTE_ADDR']; 
	if ($ip != "IP주소") { 
?>

<!-- Menu -->
<nav id="menu">
	<div class="inner">
		<h2>메뉴</h2>
		<ul class="links">
			<li><a href="http://pikaemong.kro.kr/t/home.php">홈</a></li>
			<li><a href="http://pikaemong.kro.kr/t/news.php">새소식</a></li>
			<li><a href="http://pikaemong.kro.kr/t/admins.php">관리자</a></li>
			<li><a href="http://pikaemong.kro.kr/t/serverstauts.php">서버현황</a></li>
			<li><a href="<?= $fivem_url ?>">서버접속</a></li>
			<li><a href="<?= $discord_url ?>">디코접속</a></li>
		</ul>
		<a href="#" class="close">Close</a>
	</div>
</nav>

<?php
	} else { 
?>
			
<!-- Menu -->
<nav id="menu">
	<div class="inner">
		<h2>메뉴</h2>
		<ul class="links">
			<li><a href="http://pikaemong.kro.kr/t/home.php">홈</a></li>
			<li><a href="http://pikaemong.kro.kr/t/news.php">새소식</a></li>
			<li><a href="http://pikaemong.kro.kr/t/admins.php">관리자</a></li>
			<li><a href="http://pikaemong.kro.kr/t/serverstauts.php">서버현황</a></li>
			<li><a href="<?= $fivem_url ?>">서버접속</a></li>
			<li><a href="<?= $discord_url ?>">디코접속</a></li>
			<li><a href="http://pikaemong.kro.kr/t/board/write.php">글쓰기</a></li>
		</ul>
		<a href="#" class="close">Close</a>
	</div>
</nav>


<?php
	}
?>
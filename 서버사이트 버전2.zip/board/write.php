<?php
	require_once("config/dbconfig.php");

	//$_GET['bno']이 있을 때만 $bno 선언
	if(isset($_GET['bno'])) {
		$bNo = $_GET['bno'];
	}
		 
	if(isset($bNo)) {
		$sql = 'select b_title, b_content, b_id from board_free where b_no = ' . $bNo;
		$result = $db->query($sql);
		$row = $result->fetch_assoc();
	}
?>

<?php
	$ip = $_SERVER['REMOTE_ADDR']; 

	if ($ip != "IP주소") { 
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>포럼</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">
	
		<form action="./write_update.php" method="post" enctype="multipart/form-data" onsubmit="return formSubmit(this);">
			
			<?php
				if(isset($bNo)) {
					echo '<input type="hidden" name="bno" value="' . $bNo . '">';
				}
			?>
			
		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>
				
				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>글쓰기</h2>
							</div>
							
							<div class="inner">
								<th scope="row">차단된 IP 입니다.</th>
							</div>
					</header>

					</section>
					
				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
		</form>
	</body>
</div>
</html>

<?php
} else {
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>포럼</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">
	
		<form action="./write_update.php" method="post" enctype="multipart/form-data" onsubmit="return formSubmit(this);">
			
			<?php
				if(isset($bNo)) {
					echo '<input type="hidden" name="bno" value="' . $bNo . '">';
				}
			?>
			
		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>
				
				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>글쓰기</h2>
							</div>
							
							<div class="inner">
								<table id="boardWrite">
									<tr>
										<th scope="row"><label for="bID">역할</br>(관리자 입력)</label></th>
										<td class="id">
											<?php
											if(isset($bNo)) {
												echo $row['b_id'];
											} else { ?>
												<input type="text" name="bID" id="bID">
											<?php } ?>
										</td>
									</tr>
									
									<tr>
										<th scope="row"><label for="bTitle">제목</label></th>
										<td class="title">
										<input type="text" name="bTitle" id="bTitle" value="<?php echo isset($row['b_title'])?$row['b_title']:null?>">
										</td>
									</tr>
									
									<tr>
										<th scope="row"><label for="bContent">내용</label></th>
										<td class="content">
										<textarea name="bContent" id="bContent"><?php echo isset($row['b_content'])?$row['b_content']:null?></textarea>
										</td>
									</tr>
								</table>
						
								<div class="btnSet">
									<button type="submit" class="btnSubmit btn">
										<?php echo isset($bNo)?'수정':'작성'?>
									</button>
									<a href="../news.php" class="btnList btn">취소</a>
								</div>
					
							</div>
					</header>

					</section>
					
				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
		</form>
	</body>
</div>
</html>

<?php
}
?>
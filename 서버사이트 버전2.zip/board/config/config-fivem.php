<?php
$ip = "서버 아이피";
$port = "서버 포트";
$fivem_url = "fivem://connect/다이렉트 주소";
$discord_url = "https://discord.gg/뒷자리";
$max_slots = "1000";
?>
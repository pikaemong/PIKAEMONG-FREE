<?php
	session_start();
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>메인화면</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>

<!-- Scrollbar -->
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>

				<!-- Banner -->
					<section id="banner">
						<div class="inner">
							<h2>피카에몽</h2>
							<p>냠냠쩝쩝 하는중</p>
						</div>
					</section>

				<!-- Wrapper -->
					<section id="wrapper">

						<!-- One -->
							<section id="one" class="wrapper spotlight style1">
								<div class="inner">
									<a class="image"><img src="images/pic10.jpg" alt="" /></a>
									<div class="content">
										<h2 class="major">1번</h2>
										<p>설명1<br>설명2</br>설명3</p>
									</div>
								</div>
							</section>

						<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
									<a class="image"><img src="images/pic02.jpg" alt="" /></a>
									<div class="content">
										<h2 class="major">2번</h2>
										<p>설명1<br>설명2</br>설명3</p>
									</div>
								</div>
							</section>
					</section>

				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
	</body>
</div>
</html>
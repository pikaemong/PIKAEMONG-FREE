<?php
	session_start();
?> 

<?
    $mobileKeyWords = array ('iPhone', 'iPod', 'BlackBerry', 'Android', 'Windows CE', 'Windows CE;', 'LG', 'MOT', 'SAMSUNG', 'SonyEricsson', 'Mobile', 'Symbian', 'Opera Mobi', 'Opera Mini', 'IEmobile');
 
    $isMobile = 0;
 
    for($i = 0 ; $i < count($mobileKeyWords) ; $i++)
    {
        if(strpos($_SERVER['HTTP_USER_AGENT'],$mobileKeyWords[$i]) == true)
        {
            $isMobile = 1;
            break;
        }
    }
 
    if( $isMobile == 1 )
    {
        $mbU = "/m" . $_SERVER['REQUEST_URI'];
    }
?>

<?php
	require_once("board/config/dbconfig.php");
	
	/* 페이징 시작 */
	//페이지 get 변수가 있다면 받아오고, 없다면 1페이지를 보여준다.
	if(isset($_GET['page'])) {
		$page = $_GET['page'];
	} else {
		$page = 1;
	}
	
	/* 검색 시작 */
	
	if(isset($_GET['searchColumn'])) {
		$searchColumn = $_GET['searchColumn'];
		$subString .= '&amp;searchColumn=' . $searchColumn;
	}
	if(isset($_GET['searchText'])) {
		$searchText = $_GET['searchText'];
		$subString .= '&amp;searchText=' . $searchText;
	}
	
	if(isset($searchColumn) && isset($searchText)) {
		$searchSql = ' where ' . $searchColumn . ' like "%' . $searchText . '%"';
	} else {
		$searchSql = '';
	}
	
	/* 검색 끝 */
	
	$sql = 'select count(*) as cnt from board_free' . $searchSql;
	$result = $db->query($sql);
	$row = $result->fetch_assoc();
	
	$allPost = $row['cnt']; //전체 게시글의 수
	
	if(empty($allPost)) {
		$emptyData = '<tr><td class="textCenter" colspan="5">글이 존재하지 않습니다.</td></tr>';
	} else {

		$onePage = 1000000000; // 한 페이지에 보여줄 게시글의 수.
		$allPage = ceil($allPost / $onePage); //전체 페이지의 수
		
		if($page < 1 && $page > $allPage) {
?>
			<script>
				alert("존재하지 않는 페이지입니다.");
				history.back();
			</script>
<?php
			exit;
		}
		
		$currentLimit = ($onePage * $page) - $onePage; //몇 번째의 글부터 가져오는지
		$sqlLimit = ' limit ' . $currentLimit . ', ' . $onePage; //limit sql 구문
		
		$sql = 'select * from board_free' . $searchSql . ' order by b_no desc' . $sqlLimit; //원하는 개수만큼 가져온다. (0번째부터 20번째까지
		$result = $db->query($sql);
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>새소식</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>

<!-- Scrollbar -->
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>

				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>새소식</h2>
							</div>
						</header>
						
						<!-- Content -->
							<div class="wrapper">
								<div class="inner">
									<section class="features">
															<?php
if(isset($emptyData)) {
echo $emptyData;
} else {
while($row = $result->fetch_assoc())
{
$datetime = explode(' ', $row['b_date']);
$date = $datetime[0];
$time = $datetime[1];
if($date == Date('Y-m-d'))
$row['b_date'] = $time;
else
$row['b_date'] = $date;
?>
<article>
<a href="./board/view.php?pikaemong=<?php echo $row['b_no']?>" class="image"><img src="images/news.jpg" alt="" /></a>
<h3 class="major"><?php echo $row['b_title']?></h3>
<p><?php echo $row['b_date']?></p>
<a href="./board/view.php?pikaemong=<?php echo $row['b_no']?>" class="special">더보기</a>
</article>
<?php
}
}
?>
									</section>
								</div>
							</div>
							

					</section>

				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
	</body>
</div>
</html>
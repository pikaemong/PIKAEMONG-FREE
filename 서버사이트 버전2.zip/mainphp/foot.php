<!-- Scripts -->
<script src="board/assets/js/jquery.min.js"></script>
<script src="board/assets/js/jquery.scrollex.min.js"></script>
<script src="board/assets/js/browser.min.js"></script>
<script src="board/assets/js/breakpoints.min.js"></script>
<script src="board/assets/js/util.js"></script>
<script src="board/assets/js/main.js"></script>
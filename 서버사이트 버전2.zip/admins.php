<?php
	session_start();
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>관리자</title>
		<?php 
			include_once("mainphp/head.php");
		?>
	</head>

<!-- Scrollbar -->
<div id="scrollbar" class="scrollbar">

	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">
				<?php 
					include_once("mainphp/menu.php");
				?>

				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>관리자</h2>
							</div>
						</header>

						<!-- Content -->
							<div class="wrapper">
								<div class="inner">
									<section class="features">
										<article>
											<a class="image">
											<img src="images/pic04.jpg" alt="" />
											</a>
											<h3 class="major">관리자 이름</h3>
											<p>관리자 소개1<br>
											   관리자 소개2</br>
											</p>
										</article>
										<article>
											<a class="image">
											<img src="images/pic05.jpg" alt="" />
											</a>
											<h3 class="major">관리자 이름</h3>
											<p>관리자 소개1<br>
											   관리자 소개2</br>
											</p>
										</article>
									</section>
								</div>
							</div>

					</section>

				<!-- Footer -->
					<?php 
						include_once("mainphp/svad.php");
					?>
			</div>
			<?php 
				include_once("mainphp/foot.php");
			?>
	</body>
</div>
</html>